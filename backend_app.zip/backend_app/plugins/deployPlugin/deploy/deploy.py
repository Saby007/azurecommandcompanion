import os
import subprocess
from semantic_kernel.skill_definition import (
    sk_function,
    sk_function_context_parameter,
)
from semantic_kernel.orchestration.sk_context import SKContext

# Deploy class is used to execute the az cli commands
class Deploy:
    @sk_function(
        description="execute the az cli command",
        name="deploy_func",
        input_description="Execute the az cli command",
    )
    @sk_function_context_parameter(
        name="command",
        description="Az cli command",
    )
    @sk_function_context_parameter(
        name="user",
        description="Service principal user",
    )
    @sk_function_context_parameter(
        name="password",
        description="Service principal password",
    )
    @sk_function_context_parameter(
        name="tenantid",
        description="Tenant id",
    )
    def deploy_func(self, context: SKContext)-> str:
        # Login command
        login_command = "az login --service-principal -u "+ context["user"]+" -p="+context["password"]+ " --tenant "+ context["tenantid"]
        login_result = subprocess.run(login_command, capture_output=True, text=True, shell=True)

        if login_result.returncode != 0:
            return "Login Failed: " + login_result.stderr
        
        result = subprocess.run(context["command"], capture_output=True, text=True, shell=True)
        print(result)
        if(result.returncode == 0):
            return result.stdout
        else:
            return result.stderr
        