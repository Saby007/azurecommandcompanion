import os
import time
import semantic_kernel as sk
from flask_cors import CORS
from dotenv import load_dotenv, dotenv_values
from flask import Flask, request
from plugins.deployPlugin.deploy.deploy import Deploy
from semantic_kernel.connectors.ai.open_ai import (AzureChatCompletion)

# setting app and CORS
app = Flask(__name__)
CORS(app)

# Semantic functions are used to call the semantic skills
# 1. Creating the json schema of key attributes from user's input
# 2. Creating the az cli commands from user's input
def semanticFunctions(kernel, skills_directory,skill_plugin_name, skill_name,input):    
    functions = kernel.import_semantic_skill_from_directory(skills_directory,skill_plugin_name)
    semanticFunction = functions[skill_name]
    return semanticFunction(input)

# Native functions are used to call the native skills
# 1. Execute the az cli commands
def nativeFunctions(kernel, context, plugin_class,skill_name, function_name):
    native_plugin = kernel.import_skill(plugin_class, skill_name)
    function = native_plugin[function_name]    
    return function.invoke(context=context) 

# Process the info related input from the user
@app.route('/process_info', methods=['POST'])
def process_info():

    # Create kernel objects
    kernel = sk.Kernel()
    context = kernel.create_new_context()
    load_dotenv()
    kernel.add_chat_service("chat_completion", AzureChatCompletion(deployment_name=os.environ.get("AZURE_OPEN_AI__CHAT_COMPLETION_DEPLOYMENT_NAME"),
                                                                   endpoint=os.environ.get("AZURE_OPEN_AI__ENDPOINT"),
                                                                   api_key=os.environ.get("AZURE_OPEN_AI__API_KEY", None)))

    #Getting user input
    user_input = request.data.decode('utf-8')
    
    skills_directory = "./plugins"
    print("Generating the command............... ")
    start = time.time()
    command = semanticFunctions(kernel, skills_directory,"commandPlugin","command",user_input).result
    print("Time taken(secs): ", time.time() - start)
    print("Command: ", command)

    #checking whether it is an info command or not
    if any(word in command for word in ["list", "show", "get"]):
        print("Generating the info............... ")
        context["command"] = command
        context["user"] = os.environ.get("SERVICE_PRINCIPAL_USER")
        context["password"] = os.environ.get("SERVICE_PRINCIPAL_PASSWORD")
        context["tenantid"] = os.environ.get("TENANT_ID")
        start = time.time()
        deployment_result = nativeFunctions(kernel, context, Deploy(),"deployPlugin","deploy_func").result
        print("Time taken(secs): ", time.time() - start)
        print("Info: ", deployment_result)
    else:
        deployment_result = "This is not an info command"

    return command + "|" + deployment_result

# Process the command from the user
@app.route('/process_command', methods=['POST'])
def process_command():
    # Create kernel objects
    kernel = sk.Kernel()
    context = kernel.create_new_context()
    load_dotenv()
    kernel.add_chat_service("chat_completion", AzureChatCompletion(deployment_name=os.environ.get("AZURE_OPEN_AI__CHAT_COMPLETION_DEPLOYMENT_NAME"),
                                                                   endpoint=os.environ.get("AZURE_OPEN_AI__ENDPOINT"),
                                                                   api_key=os.environ.get("AZURE_OPEN_AI__API_KEY", None)))

    #Getting user input
    user_input = request.data.decode('utf-8')

    skills_directory = "./plugins"
    print("Generating the schema............... ")
    start = time.time()
    template = semanticFunctions(kernel, skills_directory,"templatePlugin","template",user_input).result
    print("Time taken(secs): ", time.time() - start)
    if template[0] == '{' or template[0] == '[':
        start = time.time()
        command = semanticFunctions(kernel, skills_directory,"commandPlugin","command",user_input).result
        print("Time taken(secs): ", time.time() - start)
        print("Command: ", command)
    else:
        command = ""
    return template + "|" + command

# Process the config related input from the user
@app.route('/process_config', methods=['POST'])
def process_config():
    # Create kernel objects
    kernel = sk.Kernel()
    context = kernel.create_new_context()
    load_dotenv()
    kernel.add_chat_service("chat_completion", AzureChatCompletion(deployment_name=os.environ.get("AZURE_OPEN_AI__CHAT_COMPLETION_DEPLOYMENT_NAME"),
                                                                   endpoint=os.environ.get("AZURE_OPEN_AI__ENDPOINT"),
                                                                   api_key=os.environ.get("AZURE_OPEN_AI__API_KEY", None)))

    #Getting user input
    user_input = request.data.decode('utf-8')
    
    skills_directory = "./plugins"
    print("Generating the command............... ")
    start = time.time()
    command = semanticFunctions(kernel, skills_directory,"commandPlugin","command",user_input).result
    print("Time taken(secs): ", time.time() - start)
    print("Command: ", command)

    #checking whether it is a config command or not
    if any(word in command for word in ["set"]):
        print("Generating the info............... ")
        context["command"] = command
        context["user"] = os.environ.get("SERVICE_PRINCIPAL_USER")
        context["password"] = os.environ.get("SERVICE_PRINCIPAL_PASSWORD")
        context["tenantid"] = os.environ.get("TENANT_ID")
        start = time.time()
        deployment_result = nativeFunctions(kernel, context, Deploy(),"deployPlugin","deploy_func").result
        print("Time taken(secs): ", time.time() - start)
        print("Info: ", deployment_result)
    else:
        deployment_result = "This is not a config command"

    return command 

# Process the deploy related input from the user
@app.route('/process_deploy', methods=['POST'])
def process_deploy():

    kernel = sk.Kernel()
    context = kernel.create_new_context()

    #Getting user input
    context["command"] = request.data.decode('utf-8')
    context["user"] = os.environ.get("SERVICE_PRINCIPAL_USER")
    context["password"] = os.environ.get("SERVICE_PRINCIPAL_PASSWORD")
    context["tenantid"] = os.environ.get("TENANT_ID")
    
    start = time.time()
    deployment_result = nativeFunctions(kernel, context, Deploy(),"deployPlugin","deploy_func").result
    print("Time taken(secs): ", time.time() - start)

    return deployment_result

if __name__ == '__main__':
    app.run(host='0.0.0.0', debug=True, port=8080)
